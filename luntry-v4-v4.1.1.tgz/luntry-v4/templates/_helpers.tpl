{{- define "name" -}}
{{- default .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "fullname" -}}
{{- $name := default .Chart.Name -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create pull secret
*/}}
{{- define "imagePullSecret" }}
{{- with .Values.imageCredentials }}
{{- printf "{\"auths\":{\"%s\":{\"username\":\"%s\",\"password\":\"%s\",\"email\":\"%s\",\"auth\":\"%s\"}}}" .registry .username .password .email (printf "%s:%s" .username .password | b64enc) | b64enc }}
{{- end }}
{{- end }}

{{/*
Return the proper dbwait image name
*/}}
{{- define "dbwait.image" -}}
{{- $registryName := .Values.imageCredentials.registry -}}
{{- $repositoryName := .Values.imageCredentials.repository -}}
{{- $tag := .Values.dbwait.image.tag | toString -}}
{{- printf "%s/%s:%s" $registryName $repositoryName $tag -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "common.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ template "name" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: {{ .Chart.Name }}
{{- end }}

{{/*
PG SSL mount
*/}}
{{- define "pg.tls.mount" -}}
{{- if .Values.databaseConnectionConfiguration.postgres.tls.enabled }}
- name: pg-ca
  secret:
    secretName: {{ .Values.databaseConnectionConfiguration.postgres.tls.ca.secretName | default (printf "%s-%s" .Release.Name "pg-tls-ca") }}
    items:
      - key: {{ .Values.databaseConnectionConfiguration.postgres.tls.ca.secretKey | default "ca.crt"  }}
        path: {{ .Values.databaseConnectionConfiguration.postgres.tls.ca.secretKey | default "ca.crt" }}
{{- end }}
{{- end }}

{{- define "pg.tls.ca.mount.path" -}}
{{- printf "%s/%s" .Values.databaseConnectionConfiguration.postgres.tls.caMountPath .Values.databaseConnectionConfiguration.postgres.tls.caFileName -}}
{{- end -}}

{{- define "postgres.tls.ca.volumeMount" -}}
{{- if .Values.databaseConnectionConfiguration.postgres.tls.enabled }}
- name: pg-ca
  mountPath: {{ include "pg.tls.ca.mount.path" . }}
  subPath: {{ .Values.databaseConnectionConfiguration.postgres.tls.caFileName }}
{{- end }}
{{- end }}


{{/*
CA bundle mount
*/}}
{{- define "caBundle.mount" -}}
- name: ca-bundle
  secret:
    secretName: {{ .Values.caBundle.secretName | default (printf "%s-%s" .Release.Name "ca-bundle") }}
{{- end }}

{{/*
Return Kafka host
*/}}
{{- define "kafkaHost" -}}
{{- if .Values.kafka.enabled -}}
{{- printf "%s-%s.%s:%s" .Release.Name "kafka" .Release.Namespace (include "kafkaPort" .) -}}
{{- else -}}
{{- printf "%s:%s" .Values.databaseConnectionConfiguration.kafka.host (include "kafkaPort" .) -}}
{{- end -}}
{{- end -}}

{{/*
Return Kafka port
*/}}
{{- define "kafkaPort" -}}
{{- if .Values.kafka.enabled -}}
{{- printf "%s" "9092" -}}
{{- else -}}
{{- $port := .Values.databaseConnectionConfiguration.kafka.port | toString -}}
{{- printf "%s" .Values.databaseConnectionConfiguration.kafka.port -}}
{{- end -}}
{{- end -}}

{{/*
Return ClickHouse host
*/}}
{{- define "clickHouseHost" -}}
{{- if .Values.clickhouse.enabled -}}
{{- printf "%s-%s.%s" .Release.Name "clickhouse" .Release.Namespace -}}
{{- else -}}
{{- $clickHouseHost := .Values.databaseConnectionConfiguration.clickhouse.host -}}
{{- printf $clickHouseHost -}}
{{- end -}}
{{- end -}}

{{/*
Return Postgres's host
*/}}
{{- define "postgresHost" -}}
{{- if .Values.postgres.enabled -}}
{{- printf "%s-%s.%s" .Release.Name "postgres" .Release.Namespace -}}
{{- else -}}
{{- $postgresHost := .Values.databaseConnectionConfiguration.postgres.host -}}
{{- printf $postgresHost -}}
{{- end -}}
{{- end -}}

{{/*
Return Postgres's port
*/}}
{{- define "postgresPort" -}}
{{- if .Values.postgres.enabled -}}
{{- printf "%s" "5432" -}}
{{- else -}}
{{- $port := .Values.databaseConnectionConfiguration.postgres.port | toString -}}
{{- printf "%s" .Values.databaseConnectionConfiguration.postgres.port -}}
{{- end -}}
{{- end -}}

{{/*
Return Redis host
*/}}
{{- define "redisHost" -}}
{{- if .Values.redis.enabled -}}
{{- printf "%s-%s.%s:%s" .Release.Name "redis" .Release.Namespace (include "redisPort" .) -}}
{{- else -}}
{{- $redisHost := .Values.databaseConnectionConfiguration.redis.host -}}
{{- printf "%s:%s" $redisHost (include "redisPort" .) -}}
{{- end -}}
{{- end -}}

{{/*
Return Redis port
*/}}
{{- define "redisPort" -}}
{{- if .Values.redis.enabled -}}
{{- printf "%s" "6379" -}}
{{- else -}}
{{- $redisPort := .Values.databaseConnectionConfiguration.redis.port | toString -}}
{{- printf $redisPort -}}
{{- end -}}
{{- end -}}

{{/*
Return exporter host
*/}}
{{- define "exporterHost" -}}
{{- if not .Values.multicluster.exporter.host -}}
{{- printf "%s-%s.%s:%s" .Release.Name "exporter" .Release.Namespace "3337" -}}
{{- else -}}
{{- printf "%s:%s" .Values.multicluster.exporter.host .Values.multicluster.exporter.port -}}
{{- end -}}
{{- end -}}

{{/*
Return networker host
*/}}
{{- define "networkerHost" -}}
{{- printf "%s-%s.%s:%s" .Release.Name "networker" .Release.Namespace "12345" -}}
{{- end -}}

{{/*
Return watcher await endpoint
*/}}
{{- define "watcherAwaitEndpoint" -}}
{{- printf "%s://%s-%s.%s:%s/%s" "http" .Release.Name "watcher" .Release.Namespace "8080" "ready" -}}
{{- end -}}

{{/*
Return supervisor host
*/}}
{{- define "supervisorHost" -}}
{{- printf "%s://%s-%s.%s:%s" "http" .Release.Name "supervisor" .Release.Namespace "8080/ready" -}}
{{- end -}}

{{/*
Return linker host
*/}}
{{- define "linkerPolicyHost" -}}
{{- printf "%s-%s.%s:%s" .Release.Name "linker" .Release.Namespace "12346" -}}
{{- end -}}

{{- define "linkerLinksHost" -}}
{{- printf "%s-%s.%s:%s" .Release.Name "linker" .Release.Namespace "12347" -}}
{{- end -}}

{{/*
Return collector endpoint
*/}}
{{- define "collectorEndpoint" -}}
{{- printf "%s-%s.%s:%s" .Release.Name "collector" .Release.Namespace "31337" -}}
{{- end -}}

{{/*
Return dataprovider host
*/}}
{{- define "dataProviderEndpoint" -}}
{{- printf "%s-%s.%s:%s" .Release.Name "data-provider" .Release.Namespace "80" -}}
{{- end -}}

{{/*
Return supervisor api host
*/}}
{{- define "supervisorAddress" -}}
{{- printf "%s-%s.%s:%s" .Release.Name "supervisor" .Release.Namespace "31337" -}}
{{- end -}}

{{/*
Return checker addr
*/}}
{{- define "checkerAddress" -}}
{{- printf "%s-%s.%s:%s" .Release.Name "checker" .Release.Namespace "20173" -}}
{{- end -}}

{{/*
Return checker grpc addr
*/}}
{{- define "checkerGrpcEndpoint" -}}
{{- printf "%s-%s.%s:%s" .Release.Name "checker" .Release.Namespace "20172" -}}
{{- end -}}

{{/*
Return charon addr
*/}}
{{- define "charonAddress" -}}
{{- printf "%s://%s-%s.%s:%s" "http" .Release.Name "charon" .Release.Namespace "8080/ready" -}}
{{- end -}}

{{/*
Return cmd-dispatcher addr
*/}}
{{- define "commanderAddress" -}}
{{- printf "%s-%s.%s:%s" .Release.Name "cmd-dispatcher" .Release.Namespace "8080" -}}
{{- end -}}

{{/*
Return sbom-scanner addr
*/}}
{{- define "sbomScannerAddress" -}}
{{- printf "%s-%s.%s:%s" .Release.Name "sbom-scanner" .Release.Namespace "8080" -}}
{{- end -}}

{{/*
Return cronjob apiversion
*/}}
{{- define "cronJobApiVersion" -}}
{{- if .Capabilities.APIVersions.Has "batch/v1/CronJob" -}}
{{- printf "batch/v1" -}}
{{- else -}}
{{- printf "batch/v1beta1" -}}
{{- end -}}
{{- end -}}

{{/*
Return gateway endpoint
*/}}
{{- define "gatewayEndpoint" -}}
{{- if or (not .Values.multicluster.enabled ) (and (.Values.multicluster.enabled ) ( eq .Values.multicluster.role "main" )) -}}
  {{ .Release.Name }}-gateway.{{ .Release.Namespace }}:{{ .Values.gateway.service.port }}
{{- else if and (.Values.multicluster.enabled ) ( eq .Values.multicluster.role "secondary" ) -}}
  {{ .Values.multicluster.gateway.host }}:{{ .Values.multicluster.gateway.port }}
{{- end -}}
{{- end -}}

{{/*
Return vulndb address
*/}}
{{- define "vulndbAddress" -}}
{{- printf "%s://%s-%s.%s:%s" "http" .Release.Name "vulndb" .Release.Namespace "8080" -}}
{{- end -}}

{{/*
Render a compatible securityContext depending on the platform. By default it is maintained as it is. In other platforms like Openshift we remove default user/group values that do not work out of the box with the restricted-v1 SCC
Usage:
{{- include "common.compatibility.renderSecurityContext" (dict "secContext" .Values.containerSecurityContext "context" $) -}}
*/}}
{{- define "renderSecurityContext" -}}
{{- $adaptedContext := .secContext -}}
{{- if .context.Values.openShift.compatibility.adaptSecurityContext -}}
  {{/* Remove incompatible user/group values that do not work in Openshift out of the box */}}
  {{- $adaptedContext = omit $adaptedContext "fsGroup" "runAsUser" "runAsGroup" "runAsNonRoot" -}}
  {{- if not .secContext.seLinuxOptions -}}
    {{/* If it is an empty object, we remove it from the resulting context because it causes validation issues */}}
    {{- $adaptedContext = omit $adaptedContext "seLinuxOptions" -}}
  {{- end -}}
{{- end -}}
{{- $adaptedContext | toYaml -}}
{{- end -}}

{{/*
KAFKA SSL mount
*/}}
{{- define "kafka.ssl.volume" -}}
{{- if .Values.databaseConnectionConfiguration.kafka.ssl.enabled }}
- name: kafka-ca
  secret:
    secretName: {{ .Values.databaseConnectionConfiguration.kafka.ssl.ca.secretName | default (printf "%s-%s" .Release.Name "kafka-ssl-ca") }}
    items:
      - key: {{ .Values.databaseConnectionConfiguration.kafka.ssl.ca.secretKey | default "kafka-ca.crt"  }}
        path: {{ .Values.databaseConnectionConfiguration.kafka.ssl.ca.secretKey | default "kafka-ca.crt" }}
{{- end }}
{{- end }}

{{- define "kafka.ssl.volumeMount" -}}
{{- if .Values.databaseConnectionConfiguration.kafka.ssl.enabled }}
- name: kafka-ca
  mountPath: {{ .Values.databaseConnectionConfiguration.kafka.ssl.caPath }}
  subPath: {{ .Values.databaseConnectionConfiguration.kafka.ssl.ca.secretKey | default "kafka-ca.crt" }}
{{- end }}
{{- end }}

{{- define "kafka.security.protocol" -}}
{{- if or ( eq .Values.databaseConnectionConfiguration.kafka.authMechanism "SCRAM-SHA-256" ) ( eq .Values.databaseConnectionConfiguration.kafka.authMechanism "SCRAM-SHA-512" ) }}
{{- if .Values.databaseConnectionConfiguration.kafka.ssl.enabled }}
{{- printf "SASL_SSL" -}}
{{- else }}
{{- printf "SASL_PLAINTEXT" -}}
{{- end }}
{{- else }}
{{- printf "SASL_PLAINTEXT" -}}
{{- end }}
{{- end }}